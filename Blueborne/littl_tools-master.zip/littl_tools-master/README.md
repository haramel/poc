# littl_tools
### some little tools to make worker easyer

## syms2idc.py
- make a idc file for IDA to get kernel symbols form kallsyms
- usage:./syms2idc.py \<syms\_file\> \<idc\_file\_name>


## android_root
- easy root code for android root learning

## pixel_c_image
- get Image from Image.fit for pixel C
- usage: ./get_image.py \<Image_fit\_file\> \<out\_file\_name>


## bluetooth
- bluetooth vulnerability study